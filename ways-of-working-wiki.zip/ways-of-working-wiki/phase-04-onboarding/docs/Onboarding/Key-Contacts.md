# Key Contacts

Use this page to find the right person for common questions and requests.

## Team Contacts

| Name                      | Role                     | Area of Responsibility                                         | Contact                      |
| ------------------------- | ------------------------ | -------------------------------------------------------------- | ---------------------------- |
| <!-- e.g., Jane Smith --> | <!-- e.g., Tech Lead --> | <!-- e.g., Architecture decisions, code review escalations --> | <!-- e.g., Teams / email --> |
|                           |                          |                                                                |                              |
|                           |                          |                                                                |                              |

## Escalation Paths

<!-- Describe who to contact for production incidents, security issues, access problems, and other urgent matters. -->

## External Contacts

<!-- List key contacts outside the immediate team — e.g., platform team, security team, product owners, UX. -->
