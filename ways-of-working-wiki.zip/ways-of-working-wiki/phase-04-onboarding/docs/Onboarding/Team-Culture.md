# Team Culture

Understanding how the team works day-to-day is just as important as understanding the codebase.

## Communication Norms

<!-- Describe the team's expectations for communication — e.g., preferred channels (chat vs email), response time expectations, when to use async vs sync communication. -->

## Meeting Etiquette

<!-- List the recurring meetings (standup, retro, planning) with schedule and expectations. Describe norms like cameras on/off, agenda preparation, note-taking. -->

## Team Values

<!-- Describe the values the team operates by — e.g., psychological safety, ownership, continuous improvement, transparency. -->
