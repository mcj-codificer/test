# Tech Radar

The Tech Radar tracks the technologies we use and our stance on adopting new ones. It helps teams make aligned technology choices.

## How to Read the Radar

| Ring       | Meaning                                                                                      |
| ---------- | -------------------------------------------------------------------------------------------- |
| **Adopt**  | Proven and recommended for use. Default choice for new work.                                 |
| **Trial**  | Worth trying on a non-critical project. Gather experience before wider adoption.             |
| **Assess** | Interesting — investigate and understand. Not yet ready for project use.                     |
| **Hold**   | Do not start new work with this technology. Existing usage may continue but plan to migrate. |

## Radar

| Technology           | Category                | Ring                 | Notes                    |
| -------------------- | ----------------------- | -------------------- | ------------------------ |
| <!-- e.g., React --> | <!-- e.g., Frontend --> | <!-- e.g., Adopt --> | <!-- Brief rationale --> |
|                      |                         |                      |                          |
|                      |                         |                      |                          |

<!-- Add rows as the team evaluates technologies. Review the radar periodically (e.g., quarterly). -->
