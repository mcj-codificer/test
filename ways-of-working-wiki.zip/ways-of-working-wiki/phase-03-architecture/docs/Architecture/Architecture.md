# Architecture

This section documents our architectural principles, technology choices, and the decision records that explain why we built things the way we did.

## Overview

<!-- Provide a high-level description of the system architecture — key components, boundaries, and how they interact. -->

## When to Write an ADR

Architecture Decision Records capture significant technical decisions. Write an ADR when:

- Choosing or replacing a technology, framework, or service.
- Defining a pattern that multiple teams or services will follow.
- Making a trade-off that future developers will need context on.
- Reversing or superseding a previous decision.

See the [ADRs](./ADRs/ADRs.md) section for the template and index.
