# Getting Started

Use this checklist on your first day to get your accounts and access set up.

## Day 1 Checklist

- [ ] Receive and set up your laptop
- [ ] Get added to the organisation's Azure DevOps instance
- [ ] Get added to the relevant team(s) and repositories
- [ ] Set up email, calendar, and chat (e.g., Teams / Slack)
- [ ] Join the key team channels
- [ ] Clone the main repositories and verify you can build locally
- [ ] Meet your onboarding buddy
- [ ] Review the [Engineering Practices](../Engineering-Practices/Engineering-Practices.md) section of this wiki
- [ ] Bookmark this wiki for future reference

## Access Requests

<!-- List the systems that require access requests and how to raise them (e.g., ServiceNow, IT portal, team lead). -->

## Onboarding Buddy

<!-- Describe the buddy system — who assigns buddies, what the buddy's role is, and how long the pairing lasts. -->
