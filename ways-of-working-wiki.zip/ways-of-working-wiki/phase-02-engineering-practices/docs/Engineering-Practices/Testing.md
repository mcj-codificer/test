# Testing

Testing gives us confidence to ship changes quickly without breaking existing functionality.

## Testing Philosophy

<!-- Describe the team's approach to testing — e.g., test pyramid, shift-left, when to write tests, what not to test. -->

## Coverage Expectations

<!-- Define coverage targets (if any), how coverage is measured, and how it is enforced in CI. -->

## Test Types

<!-- Describe the types of tests used (unit, integration, end-to-end, contract, performance) and when each is appropriate. -->
