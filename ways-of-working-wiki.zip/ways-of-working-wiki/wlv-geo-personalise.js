/**
 * ═══════════════════════════════════════════════════════════════════
 *  University of Wolverhampton — Course Page Geo-Personalisation v4
 *  Paste into DevTools console on any wlv.ac.uk/courses/* page.
 * ═══════════════════════════════════════════════════════════════════
 *
 *  What it does
 *  ─────────────
 *  1. Detects the visitor's country via the ipapi.co free API (no key needed).
 *  2. Shows a dismissable top-of-page banner for non-UK visitors with:
 *       • Their detected country flag & name
 *       • A plain-English summary of international student status
 *       • Quick links to the international admissions & fees pages
 *  3. Finds the on-page Fees section and:
 *       • Highlights the relevant fee row (Home or International)
 *       • Collapses the irrelevant category behind a "Show all fees" toggle
 *       • Injects a context card explaining what the fee means for them
 *  4. Injects a compact duplicate of the context card immediately below
 *     the secondary (course) navigation, so it's visible without scrolling.
 *  5. Injects a floating badge (bottom-right) showing the active fee profile:
 *       • Left side  → clicks to expand the Fees tab and scroll to the card
 *       • Right side → opens a country picker to simulate any other country,
 *         instantly re-rendering all personalised content
 *
 *  v4 changes over v3
 *  ───────────────────
 *  • Badge split into jump-to-fees (left) and country picker toggle (right)
 *  • jumpToFees() clicks the "Fees" tab in the secondary nav to expand the
 *    section before scrolling, so hidden content is revealed first
 *  • Duplicate compact fee card injected under the secondary nav bar
 *  • Both injected cards are cleaned up and rebuilt on country change
 * ═══════════════════════════════════════════════════════════════════
 */

(async function wlvGeoV4() {

  /* ─── 0. Brand tokens ────────────────────────────────────────────── */
  const GOLD  = '#f5a800';
  const NAVY  = '#003057';
  const TEAL  = '#007b8a';
  const GREEN = '#2e7d32';
  const WHITE = '#ffffff';
  const FONT  = "'Source Sans Pro', Arial, sans-serif";

  /* ─── 1. Country list for picker ────────────────────────────────── */
  const COUNTRIES = [
    { code:'GB', name:'United Kingdom' }, { code:'IE', name:'Ireland' },
    { code:'IN', name:'India' },          { code:'CN', name:'China' },
    { code:'NG', name:'Nigeria' },        { code:'PK', name:'Pakistan' },
    { code:'US', name:'United States' },  { code:'GH', name:'Ghana' },
    { code:'ZW', name:'Zimbabwe' },       { code:'ZM', name:'Zambia' },
    { code:'KE', name:'Kenya' },          { code:'MY', name:'Malaysia' },
    { code:'HK', name:'Hong Kong' },      { code:'BD', name:'Bangladesh' },
    { code:'SL', name:'Sierra Leone' },   { code:'CM', name:'Cameroon' },
    { code:'TZ', name:'Tanzania' },       { code:'UG', name:'Uganda' },
    { code:'SA', name:'Saudi Arabia' },   { code:'AE', name:'United Arab Emirates' },
    { code:'TR', name:'Turkey' },         { code:'DE', name:'Germany' },
    { code:'FR', name:'France' },         { code:'IT', name:'Italy' },
    { code:'ES', name:'Spain' },          { code:'PL', name:'Poland' },
    { code:'RO', name:'Romania' },        { code:'NL', name:'Netherlands' },
    { code:'BE', name:'Belgium' },        { code:'SE', name:'Sweden' },
    { code:'PT', name:'Portugal' },       { code:'CZ', name:'Czech Republic' },
    { code:'HU', name:'Hungary' },        { code:'GR', name:'Greece' },
    { code:'AT', name:'Austria' },        { code:'BG', name:'Bulgaria' },
    { code:'FI', name:'Finland' },        { code:'SK', name:'Slovakia' },
    { code:'DK', name:'Denmark' },        { code:'HR', name:'Croatia' },
    { code:'LT', name:'Lithuania' },      { code:'SI', name:'Slovenia' },
    { code:'LV', name:'Latvia' },         { code:'EE', name:'Estonia' },
    { code:'CY', name:'Cyprus' },         { code:'LU', name:'Luxembourg' },
    { code:'MT', name:'Malta' },          { code:'BR', name:'Brazil' },
    { code:'MX', name:'Mexico' },         { code:'CO', name:'Colombia' },
    { code:'CA', name:'Canada' },         { code:'AU', name:'Australia' },
    { code:'NZ', name:'New Zealand' },    { code:'ZA', name:'South Africa' },
    { code:'JP', name:'Japan' },          { code:'KR', name:'South Korea' },
    { code:'TH', name:'Thailand' },       { code:'VN', name:'Vietnam' },
    { code:'ID', name:'Indonesia' },      { code:'PH', name:'Philippines' },
    { code:'SG', name:'Singapore' },      { code:'EG', name:'Egypt' },
    { code:'MA', name:'Morocco' },        { code:'ET', name:'Ethiopia' },
    { code:'SD', name:'Sudan' },
  ].sort((a, b) => a.name.localeCompare(b.name));

  const flagFor = code => code === 'XX' ? '🌍' : String.fromCodePoint(
    ...code.toUpperCase().split('').map(c => 0x1F1E6 - 65 + c.charCodeAt(0))
  );

  /* ─── 2. IP detection ───────────────────────────────────────────── */
  let detectedCode = 'XX', detectedName = 'Unknown';
  try {
    const d = await fetch('https://ipapi.co/json/').then(r => r.json());
    detectedCode = d.country_code || 'XX';
    detectedName = d.country_name  || 'Unknown';
    if (!COUNTRIES.find(c => c.code === detectedCode)) {
      COUNTRIES.push({ code: detectedCode, name: detectedName });
      COUNTRIES.sort((a, b) => a.name.localeCompare(b.name));
    }
    console.info(`[WLV-Geo v4] Detected: ${detectedName} (${detectedCode})`);
  } catch(e) {
    console.warn('[WLV-Geo v4] IP lookup failed — defaulting to Unknown');
  }

  /* ─── 3. Mutable state ──────────────────────────────────────────── */
  let activeCode = detectedCode;
  let activeName = detectedName;

  /* ─── 4. Secondary nav detection ───────────────────────────────────
     WLV course pages have a sticky sub-nav bar containing tab-like
     anchor links (Overview, Entry Requirements, Fees, etc.).
     We try several selector strategies in priority order.           */
  const findSecondaryNav = () => {
    const candidates = [
      // Primary: nav inside the sticky-wrap div (WLV course page pattern)
      () => document.querySelector('.sticky-wrap nav'),
      // Fallback 1: any other named sticky/course nav
      () => document.querySelector('.course-detail__nav, .course-nav, .js-sticky-nav, .sticky-nav'),
      // Fallback 2: any nav element whose links mention fees
      () => [...document.querySelectorAll('nav')].find(n => /fee/i.test(n.textContent)),
      // Fallback 3: role=navigation or common sub-nav class with fee link
      () => [...document.querySelectorAll('[role="navigation"], .sub-nav, .secondary-nav, .page-nav')].find(n => /fee/i.test(n.textContent)),
      // Fallback 4: walk up from any anchor linking to a fees section
      () => {
        const a = [...document.querySelectorAll('a[href*="fee" i], a[href*="#fee" i]')]
          .find(a => /fee/i.test(a.textContent));
        return a?.closest('nav, ul, [role="navigation"]') || null;
      },
    ];
    for (const fn of candidates) {
      const el = fn();
      if (el) { console.info(`[WLV-Geo v4] Secondary nav found: <${el.tagName} class="${el.className?.toString().slice(0,60)}">`); return el; }
    }
    return null;
  };

  /* ─── 5. Find and click the Fees tab, then scroll ─────────────────
     Looks for a tab/anchor inside the secondary nav whose text or
     href targets the fees section.  Clicks it to expand if needed,
     waits briefly for any animation, then scrolls the fee card into
     view.  Falls back to just scrolling if no tab is found.        */
  const jumpToFees = async () => {
    // Find a "Fees" link anywhere on the page — prefer the secondary nav
    const navEl = findSecondaryNav();
    const scope = navEl || document;

    const feeTab = (
      // Exact "Fees" text match first
      [...scope.querySelectorAll('a, button, [role="tab"]')]
        .find(el => /^\s*fees?\s*$/i.test(el.textContent.trim()))
      // Broader match if nothing exact
      ?? [...scope.querySelectorAll('a, button, [role="tab"]')]
        .find(el => /fee/i.test(el.textContent) && el.textContent.trim().length < 30)
    );

    if (feeTab) {
      console.info(`[WLV-Geo v4] Clicking fees tab: "${feeTab.textContent.trim()}"`);
      feeTab.click();
      // Allow tab-panel / accordion animation to complete before scrolling
      await new Promise(r => setTimeout(r, 350));
    } else {
      console.info('[WLV-Geo v4] No fees tab found — scrolling directly.');
    }

    // Prefer the in-fees-section card; fall back to sub-nav card or any fee element
    const target =
      document.getElementById('wlv-geo-fee-card') ||
      document.getElementById('wlv-geo-subnav-card') ||
      document.querySelector('[id*="fee" i], [class*="fee" i]');

    target?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  /* ─── 6. Build fee card inner HTML (shared by both card instances) */
  const buildCardHTML = (flag, countryName, likelyHome, isIreland, isOverride, compact = false) => {
    const overrideNote = isOverride
      ? `<p class="wlv-override-note">⚠ Simulating view from ${countryName} — detected country is ${detectedName}.</p>`
      : '';
    if (likelyHome) {
      return `
        <h3>🏠 <span class="wlv-pill">Home student</span>${compact ? '' : ` Fees for UK${isIreland ? ' / Irish' : ''} students`}</h3>
        <p>
          Based on your location in <strong>${countryName}</strong>, you are likely assessed as a
          <strong>Home student</strong> and will pay the UK-capped tuition fee rate.
          ${compact ? '' : `You may be eligible for a
          <a href="https://www.gov.uk/student-finance" target="_blank" rel="noopener">Student Finance England loan</a>
          to cover fees and living costs — repayable only once you earn over the threshold.`}
          <br><a href="https://www.wlv.ac.uk/apply/funding-costs-fees-and-support/fees-and-costs/"
             target="_blank" rel="noopener">More about fees &amp; funding →</a>
        </p>${overrideNote}`;
    } else {
      return `
        <h3>${flag} <span class="wlv-pill">International student</span>${compact ? '' : ` Fees for students from ${countryName}`}</h3>
        <p>
          ${compact
            ? `Viewing from <strong>${countryName}</strong> — you'll pay the <strong>International (Overseas)</strong> fee rate.`
            : `Students from <strong>${countryName}</strong> are typically assessed as
               <strong>International (Overseas)</strong> and pay the International fee rate shown below.
               A <strong>tuition fee deposit</strong> is normally required before a CAS letter can be issued.`}
          <br>
          <a href="https://www.wlv.ac.uk/international/making-an-application/international-fees/"
             target="_blank" rel="noopener">International fees &amp; deposit info →</a>
          ${compact ? '' : `&ensp;|&ensp;<a href="https://www.wlv.ac.uk/international/making-an-application/"
             target="_blank" rel="noopener">How to apply →</a>`}
        </p>${overrideNote}`;
    }
  };

  /* ═══════════════════════════════════════════════════════════════════
     RENDER — called on load and on every country change
     ═══════════════════════════════════════════════════════════════════ */
  const render = async (countryCode, countryName) => {
    const isUK       = countryCode === 'GB';
    const isIreland  = countryCode === 'IE';
    const likelyHome = isUK || isIreland;
    const flag       = flagFor(countryCode);
    const isOverride = countryCode !== detectedCode;
    const profile    = likelyHome ? 'Home' : 'International';
    const accentCol  = likelyHome ? GREEN : TEAL;

    console.info(`[WLV-Geo v4] Rendering: ${countryName} (${countryCode}) → ${profile}${isOverride ? ' [OVERRIDE]' : ''}`);

    /* ── Tear down previous render artefacts ── */
    ['wlv-geo-banner', 'wlv-geo-fee-card', 'wlv-geo-subnav-card',
     'wlv-geo-banner-style', 'wlv-geo-fee-style'].forEach(id => document.getElementById(id)?.remove());
    document.querySelectorAll('.wlv-my-fee, .wlv-other-fee, .wlv-fee-toggle').forEach(el => {
      el.classList.remove('wlv-my-fee', 'wlv-other-fee', 'wlv-revealed');
      if (el.classList.contains('wlv-fee-toggle')) el.remove();
    });

    /* ── Banner (non-UK) ── */
    if (!isUK) {
      const bs = document.createElement('style');
      bs.id = 'wlv-geo-banner-style';
      bs.textContent = `
        #wlv-geo-banner {
          position: sticky; top: 0;
          background: ${NAVY}; color: ${WHITE};
          font-family: ${FONT};
          padding: 14px 56px 14px 18px;
          display: flex; flex-wrap: wrap; align-items: center; gap: 12px;
          z-index: 999999;
          box-shadow: 0 3px 10px rgba(0,0,0,.35);
          border-bottom: 4px solid ${GOLD};
          animation: wlv-drop .3s ease;
        }
        @keyframes wlv-drop { from{transform:translateY(-100%);opacity:0} to{transform:translateY(0);opacity:1} }
        #wlv-geo-banner .gb-flag { font-size:1.9rem; line-height:1; }
        #wlv-geo-banner .gb-text { flex:1; min-width:240px; font-size:.88rem; line-height:1.5; }
        #wlv-geo-banner .gb-text strong { color:${GOLD}; font-size:1rem; }
        #wlv-geo-banner .gb-sim {
          display:inline-block; background:${GOLD}; color:${NAVY};
          font-size:.68rem; font-weight:800; letter-spacing:.06em; text-transform:uppercase;
          padding:1px 8px; border-radius:10px; margin-left:8px; vertical-align:middle;
        }
        #wlv-geo-banner .gb-links { display:flex; gap:10px; flex-wrap:wrap; }
        #wlv-geo-banner .gb-btn {
          display:inline-block; padding:7px 14px; border-radius:4px;
          font-size:.82rem; font-weight:700; text-decoration:none;
          white-space:nowrap; transition:opacity .2s;
        }
        #wlv-geo-banner .gb-btn:hover { opacity:.82; }
        #wlv-geo-banner .gb-gold    { background:${GOLD}; color:${NAVY}; }
        #wlv-geo-banner .gb-outline { border:2px solid ${WHITE}; color:${WHITE}; }
        #wlv-geo-banner .gb-close {
          position:absolute; top:50%; right:12px; transform:translateY(-50%);
          background:none; border:none; color:${WHITE}; font-size:1.3rem;
          cursor:pointer; opacity:.7; padding:4px 8px; border-radius:3px;
          transition:opacity .2s, background .2s;
        }
        #wlv-geo-banner .gb-close:hover { opacity:1; background:rgba(255,255,255,.15); }
      `;
      document.head.appendChild(bs);

      const banner = document.createElement('div');
      banner.id = 'wlv-geo-banner';
      banner.innerHTML = `
        <span class="gb-flag">${flag}</span>
        <div class="gb-text">
          <strong>Viewing from ${countryName}?${isOverride ? '<span class="gb-sim">Simulated</span>' : ''}</strong><br>
          As an international student you'll be assessed as <em>Overseas</em> and pay the International fee rate.
          ${isIreland ? 'Irish nationals may still qualify for Home fee status — check your eligibility.' : ''}
          A tuition fee deposit is normally required before your CAS is issued.
        </div>
        <div class="gb-links">
          <a class="gb-btn gb-gold"
             href="https://www.wlv.ac.uk/international/making-an-application/"
             target="_blank" rel="noopener">International applications ↗</a>
          <a class="gb-btn gb-outline"
             href="https://www.wlv.ac.uk/international/making-an-application/international-fees/"
             target="_blank" rel="noopener">International fees ↗</a>
        </div>
        <button class="gb-close" title="Dismiss">✕</button>`;
      banner.querySelector('.gb-close').addEventListener('click', () => {
        banner.style.transition = 'max-height .3s, opacity .3s, padding .3s';
        banner.style.overflow = 'hidden';
        banner.style.maxHeight = banner.offsetHeight + 'px';
        requestAnimationFrame(() => { banner.style.maxHeight='0'; banner.style.opacity='0'; banner.style.padding='0'; });
        setTimeout(() => banner.remove(), 350);
      });
      document.body.insertBefore(banner, document.body.firstChild);
    }

    /* ── Shared card + fee-row styles ── */
    const fs = document.createElement('style');
    fs.id = 'wlv-geo-fee-style';
    fs.textContent = `
      /* ── Both fee cards share base styles ── */
      #wlv-geo-fee-card, #wlv-geo-subnav-card {
        font-family: ${FONT};
        border-left: 5px solid ${accentCol};
        border-radius: 0 8px 8px 0;
        padding: 16px 20px;
      }
      #wlv-geo-fee-card {
        background: ${likelyHome ? '#e8f5e9' : '#e3f2fd'};
        margin: 16px 0 24px;
      }
      /* Sub-nav card: slightly more compact, different bg tint */
      #wlv-geo-subnav-card {
        background: ${likelyHome ? '#f1f8f1' : '#f0f7ff'};
        margin: 0;
        border-radius: 0;
        border-left-width: 4px;
        padding: 12px 20px;
      }
      #wlv-geo-fee-card h3, #wlv-geo-subnav-card h3 {
        margin: 0 0 6px; font-size: .95rem;
        color: ${likelyHome ? '#1b5e20' : NAVY};
        display: flex; align-items: center; gap: 8px; flex-wrap: wrap;
      }
      #wlv-geo-fee-card p, #wlv-geo-subnav-card p {
        margin: 0; font-size: .87rem; color: #333; line-height: 1.6;
      }
      #wlv-geo-fee-card a, #wlv-geo-subnav-card a { color: ${TEAL}; font-weight: 600; }
      .wlv-pill {
        display: inline-block;
        background: ${accentCol}; color: ${WHITE};
        font-size: .68rem; font-weight: 700;
        letter-spacing: .05em; text-transform: uppercase;
        padding: 2px 9px; border-radius: 12px;
      }
      .wlv-override-note {
        font-size: .76rem; color: #666; font-style: italic; margin-top: 6px;
      }
      /* ── Fee table / list row highlighting ── */
      .wlv-my-fee {
        background: ${likelyHome ? '#c8e6c9' : '#bbdefb'} !important;
        outline: 2px solid ${accentCol} !important;
        outline-offset: -2px;
      }
      .wlv-my-fee td:first-child::after,
      .wlv-my-fee dt::after,
      .wlv-my-fee .wlv-fee-label::after {
        content: " ✓ Your rate";
        font-size: .68rem; font-weight: 700;
        color: ${WHITE}; background: ${accentCol};
        padding: 1px 7px; border-radius: 10px;
        margin-left: 8px; white-space: nowrap;
      }
      .wlv-other-fee { opacity: .4; transition: opacity .3s; }
      .wlv-other-fee.wlv-revealed { opacity: 1 !important; }
      .wlv-fee-toggle {
        font-family: ${FONT};
        background: none; border: 1px solid ${TEAL}; color: ${TEAL};
        padding: 5px 14px; border-radius: 4px;
        cursor: pointer; font-size: .8rem; margin-top: 10px; display: block;
      }
      .wlv-fee-toggle:hover { background: ${TEAL}; color: ${WHITE}; }
    `;
    document.head.appendChild(fs);

    /* ── Sub-nav card (compact duplicate under the secondary nav) ── */
    const subNavEl = findSecondaryNav();
    if (subNavEl) {
      const subCard = document.createElement('div');
      subCard.id = 'wlv-geo-subnav-card';
      subCard.innerHTML = buildCardHTML(flag, countryName, likelyHome, isIreland, isOverride, true);
      // Insert immediately after the secondary nav
      subNavEl.insertAdjacentElement('afterend', subCard);
      console.info(`[WLV-Geo v4] Sub-nav card inserted after <${subNavEl.tagName} class="${subNavEl.className?.toString().slice(0,40)}">`);
    } else {
      console.info('[WLV-Geo v4] Secondary nav not found — sub-nav card skipped.');
    }

    /* ── Main fee card (full version, inside the fees section) ── */
    const feeCard = document.createElement('div');
    feeCard.id = 'wlv-geo-fee-card';
    feeCard.innerHTML = buildCardHTML(flag, countryName, likelyHome, isIreland, isOverride, false);

    /* ── Fee container detection and annotation ── */
    const findFeeContainers = () => {
      const results = [];
      document.querySelectorAll('table').forEach(t => {
        if (/home|overseas|international|£\s*[\d,]+/i.test(t.textContent)) results.push({ type:'table', el:t });
      });
      document.querySelectorAll('dl').forEach(dl => {
        if (/home|overseas|international|£\s*[\d,]+/i.test(dl.textContent)) results.push({ type:'dl', el:dl });
      });
      document.querySelectorAll('[class*="fee" i],[class*="cost" i],[id*="fee" i],[id*="cost" i]').forEach(el => {
        if (el.textContent.trim().length > 10) results.push({ type:'classed', el });
      });
      const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT);
      let node;
      while ((node = walker.nextNode())) {
        if (/£\s*[\d,]+/.test(node.textContent) || /home fee|international fee|overseas fee/i.test(node.textContent)) {
          let el = node.parentElement;
          for (let i = 0; i < 5; i++) {
            if (!el) break;
            if (['TR','LI','DT','DD','DIV','P','SPAN'].includes(el.tagName)) { results.push({ type:'textNode', el }); break; }
            el = el.parentElement;
          }
        }
      }
      return results;
    };

    const waitForFees = (maxMs = 8000) => new Promise(resolve => {
      const found = findFeeContainers();
      if (found.length) { resolve(found); return; }
      const obs = new MutationObserver(() => {
        const f = findFeeContainers();
        if (f.length) { obs.disconnect(); clearTimeout(t); resolve(f); }
      });
      obs.observe(document.body, { childList:true, subtree:true });
      const t = setTimeout(() => { obs.disconnect(); resolve([]); }, maxMs);
    });

    const annotateContainers = (containers) => {
      let highlighted = 0;
      const toggleTargets = [];
      containers.forEach(({ type, el }) => {
        if (type === 'table' || el.tagName === 'TABLE') {
          el.querySelectorAll('tr').forEach(row => {
            const txt = row.textContent;
            const isHome = /\bhome\b/i.test(txt) && !/homeless/i.test(txt);
            const isIntl = /\binternational\b|\boverseas\b/i.test(txt);
            if      (isHome && likelyHome)  { row.classList.add('wlv-my-fee'); highlighted++; }
            else if (isIntl && !likelyHome) { row.classList.add('wlv-my-fee'); highlighted++; }
            else if (isHome || isIntl)      { row.classList.add('wlv-other-fee'); toggleTargets.push(row); }
          });
        }
        if (type === 'dl' || el.tagName === 'DL') {
          el.querySelectorAll('dt').forEach(dt => {
            const dd = dt.nextElementSibling;
            const txt = dt.textContent;
            const isHome = /\bhome\b/i.test(txt);
            const isIntl = /\binternational\b|\boverseas\b/i.test(txt);
            if      (isHome && likelyHome)  { dt.classList.add('wlv-my-fee'); dd?.classList.add('wlv-my-fee'); highlighted++; }
            else if (isIntl && !likelyHome) { dt.classList.add('wlv-my-fee'); dd?.classList.add('wlv-my-fee'); highlighted++; }
            else if (isHome || isIntl)      { [dt, dd].filter(Boolean).forEach(e => { e.classList.add('wlv-other-fee'); toggleTargets.push(e); }); }
          });
        }
        if (type === 'classed') {
          [...el.querySelectorAll('*')].forEach(child => {
            if (child.children.length > 0 || child.textContent.length > 200) return;
            const txt = child.textContent.trim();
            const isHome = /\bhome\b/i.test(txt) && !/homeless/i.test(txt);
            const isIntl = /\binternational\b|\boverseas\b/i.test(txt);
            const parent = child.parentElement || child;
            if      (isHome && likelyHome)  { parent.classList.add('wlv-my-fee'); highlighted++; }
            else if (isIntl && !likelyHome) { parent.classList.add('wlv-my-fee'); highlighted++; }
            else if (isHome || isIntl)      { parent.classList.add('wlv-other-fee'); toggleTargets.push(parent); }
          });
        }
        if (type === 'textNode') {
          const txt = el.textContent;
          const isHome = /\bhome\b/i.test(txt) && !/homeless/i.test(txt);
          const isIntl = /\binternational\b|\boverseas\b/i.test(txt);
          if      (isHome && likelyHome)  { el.classList.add('wlv-my-fee'); highlighted++; }
          else if (isIntl && !likelyHome) { el.classList.add('wlv-my-fee'); highlighted++; }
          else if (isHome || isIntl)      { el.classList.add('wlv-other-fee'); toggleTargets.push(el); }
        }
      });
      const unique = [...new Set(toggleTargets)];
      if (unique.length) {
        const toggle = document.createElement('button');
        toggle.className = 'wlv-fee-toggle';
        toggle.textContent = 'Show all fee categories';
        let revealed = false;
        toggle.addEventListener('click', () => {
          revealed = !revealed;
          unique.forEach(el => el.classList.toggle('wlv-revealed', revealed));
          toggle.textContent = revealed ? 'Show relevant fees only' : 'Show all fee categories';
        });
        unique[unique.length - 1].after(toggle);
      }
      return { highlighted, dimmed: unique.length };
    };

    const findAnchor = (containers) => {
      const preferred = containers.find(c => c.type === 'table' || c.type === 'dl') || containers[0];
      let el = preferred.el;
      for (let i = 0; i < 6; i++) {
        const p = el.parentElement;
        if (!p || p === document.body) return el;
        if (['SECTION','ARTICLE','MAIN'].includes(p.tagName)) return el;
        if (/fee|cost|tuition/i.test(p.id + p.className)) return p;
        el = p;
      }
      return el;
    };

    console.info('[WLV-Geo v4] Waiting for fee content...');
    const containers = await waitForFees(8000);
    console.info(`[WLV-Geo v4] Fee containers found: ${containers.length}`);

    if (containers.length) {
      const anchor = findAnchor(containers);
      (anchor ? anchor.parentElement : document.querySelector('main,#main-content,body'))
        .insertBefore(feeCard, anchor || null);
      const { highlighted, dimmed } = annotateContainers(containers);
      console.info(`[WLV-Geo v4] ✓ ${highlighted} row(s) highlighted, ${dimmed} dimmed`);
    } else {
      console.warn('[WLV-Geo v4] No fee content found — appending card to main.');
      (document.querySelector('main,#main-content') || document.body).appendChild(feeCard);
    }

    updateBadge(countryCode, countryName, likelyHome, flag, isOverride);
    console.info(`[WLV-Geo v4] ✓ Render complete — ${profile} profile.`);
  };

  /* ═══════════════════════════════════════════════════════════════════
     FLOATING BADGE — split pill: [jump to fees] [🌐 change country ▾]
     ═══════════════════════════════════════════════════════════════════ */

  /* Badge + picker styles — injected once */
  const badgeStyle = document.createElement('style');
  badgeStyle.id = 'wlv-geo-badge-style';
  badgeStyle.textContent = `
    #wlv-geo-badge-wrap {
      position: fixed; bottom: 22px; right: 22px;
      display: flex; border-radius: 24px; overflow: visible;
      box-shadow: 0 4px 14px rgba(0,0,0,.28);
      z-index: 1000000;
      font-family: ${FONT};
      animation: wlv-pop .4s cubic-bezier(.34,1.56,.64,1);
    }
    @keyframes wlv-pop { from{transform:scale(0);opacity:0} to{transform:scale(1);opacity:1} }

    /* Left: jump to fees */
    #wlv-geo-badge-main {
      flex: 1;
      border: none; border-radius: 24px 0 0 24px;
      padding: 10px 14px 10px 16px;
      font-family: ${FONT}; font-size: .82rem; font-weight: 700;
      color: ${WHITE}; cursor: pointer; text-align: left; line-height: 1.4;
      transition: filter .2s, background .3s;
      white-space: nowrap;
    }
    #wlv-geo-badge-main:hover { filter: brightness(1.12); }
    #wlv-geo-badge-main .badge-sub {
      display: block; font-weight: 400; font-size: .72rem; opacity: .85; margin-top: 1px;
    }

    /* Divider */
    #wlv-geo-badge-divider {
      width: 1px; background: rgba(255,255,255,.3); flex-shrink: 0; align-self: stretch;
    }

    /* Right: country picker toggle */
    #wlv-geo-badge-picker-btn {
      border: none; border-radius: 0 24px 24px 0;
      padding: 10px 14px;
      font-family: ${FONT}; font-size: .78rem; font-weight: 700;
      color: ${WHITE}; cursor: pointer; line-height: 1.4; text-align: center;
      transition: filter .2s, background .3s;
      white-space: nowrap;
    }
    #wlv-geo-badge-picker-btn:hover { filter: brightness(1.12); }
    #wlv-geo-badge-picker-btn .badge-sub {
      display: block; font-weight: 400; font-size: .72rem; opacity: .85; margin-top: 1px;
    }

    /* Picker panel */
    #wlv-geo-picker {
      position: fixed; bottom: 90px; right: 22px;
      width: 284px;
      background: ${WHITE}; border-radius: 10px;
      box-shadow: 0 8px 28px rgba(0,0,0,.22);
      z-index: 1000001; overflow: hidden;
      font-family: ${FONT};
      display: none;
      animation: wlv-picker-in .2s ease;
    }
    @keyframes wlv-picker-in { from{transform:translateY(10px);opacity:0} to{transform:translateY(0);opacity:1} }
    #wlv-geo-picker.open { display: block; }

    #wlv-geo-picker-header {
      background: ${NAVY}; color: ${WHITE};
      padding: 12px 14px 10px;
      font-size: .82rem; font-weight: 700;
      border-bottom: 3px solid ${GOLD};
      display: flex; align-items: center; justify-content: space-between;
    }
    #wlv-geo-picker-header span { opacity:.72; font-size:.72rem; font-weight:400; }
    #wlv-geo-picker-search {
      width: 100%; box-sizing: border-box;
      border: none; border-bottom: 1px solid #e0e0e0;
      padding: 10px 14px; font-size: .85rem; font-family: ${FONT}; outline: none;
    }
    #wlv-geo-picker-search:focus { border-bottom-color: ${TEAL}; }
    #wlv-geo-picker-list { max-height: 260px; overflow-y: auto; padding: 4px 0; }
    .wlv-picker-item {
      padding: 9px 14px; font-size: .85rem; cursor: pointer;
      display: flex; align-items: center; gap: 10px; transition: background .15s;
    }
    .wlv-picker-item:hover { background: #f0f4f8; }
    .wlv-picker-item.active { background: ${TEAL}; color: ${WHITE}; font-weight: 700; }
    .wlv-picker-item .pi-flag { font-size: 1.1rem; }
    .wlv-picker-item .pi-detected {
      margin-left: auto; font-size: .67rem; opacity: .65;
      border: 1px solid currentColor; padding: 1px 5px; border-radius: 8px;
    }
    #wlv-geo-picker-footer {
      padding: 8px 14px; border-top: 1px solid #eee;
      font-size: .75rem; color: #888;
      display: flex; align-items: center; justify-content: space-between;
    }
    #wlv-picker-reset {
      font-family: ${FONT};
      background: none; border: 1px solid ${TEAL}; color: ${TEAL};
      font-size: .75rem; padding: 3px 10px; border-radius: 10px; cursor: pointer;
    }
    #wlv-picker-reset:hover { background: ${TEAL}; color: ${WHITE}; }
    #wlv-picker-reset:disabled { opacity: .35; cursor: default; }
    #wlv-picker-reset:disabled:hover { background: none; color: ${TEAL}; }
  `;
  document.head.appendChild(badgeStyle);

  /* Badge wrapper */
  const badgeWrap     = document.createElement('div');
  badgeWrap.id        = 'wlv-geo-badge-wrap';
  const badgeMain     = document.createElement('button');
  badgeMain.id        = 'wlv-geo-badge-main';
  const badgeDivider  = document.createElement('div');
  badgeDivider.id     = 'wlv-geo-badge-divider';
  const badgePickBtn  = document.createElement('button');
  badgePickBtn.id     = 'wlv-geo-badge-picker-btn';
  badgeWrap.append(badgeMain, badgeDivider, badgePickBtn);
  document.body.appendChild(badgeWrap);

  /* Left button → jump to fees */
  badgeMain.addEventListener('click', () => jumpToFees());

  /* Picker panel */
  const picker = document.createElement('div');
  picker.id = 'wlv-geo-picker';
  picker.innerHTML = `
    <div id="wlv-geo-picker-header">
      Simulate a country
      <span>Re-renders all fee content</span>
    </div>
    <input id="wlv-geo-picker-search" type="text" placeholder="Search countries…" autocomplete="off">
    <div id="wlv-geo-picker-list"></div>
    <div id="wlv-geo-picker-footer">
      <span>Detected: <strong>${detectedName}</strong></span>
      <button id="wlv-picker-reset" disabled>Reset to detected</button>
    </div>`;
  document.body.appendChild(picker);

  const listEl   = picker.querySelector('#wlv-geo-picker-list');
  const searchEl = picker.querySelector('#wlv-geo-picker-search');
  const resetBtn = picker.querySelector('#wlv-picker-reset');

  const renderPickerList = (filter = '') => {
    const lc = filter.toLowerCase();
    const visible = COUNTRIES.filter(c => !lc || c.name.toLowerCase().includes(lc) || c.code.toLowerCase().includes(lc));
    listEl.innerHTML = '';
    if (!visible.length) {
      listEl.innerHTML = '<div style="padding:12px 14px;font-size:.82rem;color:#999">No countries match</div>';
      return;
    }
    visible.forEach(({ code, name }) => {
      const item = document.createElement('div');
      item.className = 'wlv-picker-item' + (code === activeCode ? ' active' : '');
      item.innerHTML = `
        <span class="pi-flag">${flagFor(code)}</span>
        <span>${name}</span>
        ${code === detectedCode ? '<span class="pi-detected">detected</span>' : ''}`;
      item.addEventListener('click', async () => {
        activeCode = code; activeName = name;
        picker.classList.remove('open');
        searchEl.value = '';
        resetBtn.disabled = (code === detectedCode);
        await render(code, name);
      });
      listEl.appendChild(item);
    });
    listEl.querySelector('.active')?.scrollIntoView({ block:'nearest' });
  };

  searchEl.addEventListener('input', () => renderPickerList(searchEl.value));

  resetBtn.addEventListener('click', async () => {
    activeCode = detectedCode; activeName = detectedName;
    resetBtn.disabled = true;
    picker.classList.remove('open');
    searchEl.value = '';
    await render(detectedCode, detectedName);
  });

  /* Right button → toggle picker */
  badgePickBtn.addEventListener('click', (e) => {
    e.stopPropagation();
    renderPickerList(searchEl.value);
    picker.classList.toggle('open');
    if (picker.classList.contains('open')) setTimeout(() => searchEl.focus(), 50);
  });

  document.addEventListener('click', (e) => {
    if (!picker.contains(e.target) && !badgeWrap.contains(e.target)) picker.classList.remove('open');
  });

  /* Update badge content + colour after each render */
  const updateBadge = (code, name, likelyHome, flag, isOverride) => {
    const bg = likelyHome ? GREEN : TEAL;
    badgeMain.style.background      = bg;
    badgePickBtn.style.background   = bg;
    badgeDivider.style.background   = 'rgba(255,255,255,.3)';
    badgeMain.innerHTML = `
      ${flag} ${likelyHome ? '🏠 Home fees' : '🌍 International fees'}
      ${isOverride ? '<span style="font-size:.64rem;opacity:.8;display:block;">⚠ Simulated</span>' : ''}
      <span class="badge-sub">↓ Jump to fees</span>`;
    badgePickBtn.innerHTML = `
      🌐
      <span class="badge-sub">Change</span>`;
    renderPickerList(searchEl.value);
  };

  /* ─── Initial render ─────────────────────────────────────────────── */
  await render(detectedCode, detectedName);

})();
