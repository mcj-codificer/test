# Architecture Decision Records

Architecture Decision Records (ADRs) capture significant technical decisions along with their context and consequences. They provide a log of what was decided, why, and what we expect to happen as a result.

## What is an ADR?

An ADR is a short document that records a single architectural decision. ADRs are numbered sequentially and are immutable once accepted — if a decision is reversed, a new ADR supersedes the original rather than editing it.

## How to Create an ADR

1. Copy the [ADR Template](./0001-ADR-Template.md) to a new file.
2. Number it sequentially (e.g., `0002-My-Decision.md`).
3. Fill in all sections — Context, Decision, and Consequences.
4. Submit a PR for team review.
5. Once accepted, add an entry to the index below and update the `.order` file.

## Index

| ADR                            | Title        | Status   | Date |
| ------------------------------ | ------------ | -------- | ---- |
| [0001](./0001-ADR-Template.md) | ADR Template | Accepted | —    |
