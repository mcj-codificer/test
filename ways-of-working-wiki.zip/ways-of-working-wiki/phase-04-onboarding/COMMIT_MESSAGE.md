Add onboarding section
