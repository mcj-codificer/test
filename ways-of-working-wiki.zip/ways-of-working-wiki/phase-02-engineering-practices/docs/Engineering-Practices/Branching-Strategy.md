# Branching Strategy

A clear branching strategy keeps the codebase stable and deployable while enabling parallel development.

## Branch Naming

<!-- Define the naming convention for branches — e.g., feature/, bugfix/, hotfix/ prefixes, ticket IDs, short descriptions. -->

## Workflow

<!-- Describe the branching workflow (e.g., trunk-based, GitFlow, GitHub Flow) and how feature work progresses from branch to main. -->

## Merge Rules

<!-- Specify merge method (squash, rebase, merge commit), required checks, and any branch protection policies. -->
