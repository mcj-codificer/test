Initialize wiki with home page and section structure
