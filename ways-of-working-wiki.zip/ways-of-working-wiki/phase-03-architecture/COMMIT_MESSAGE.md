Add architecture section with ADR template
