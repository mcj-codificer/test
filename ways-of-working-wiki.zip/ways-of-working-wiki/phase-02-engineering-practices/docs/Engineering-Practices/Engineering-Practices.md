# Engineering Practices

This section captures our shared engineering standards and processes. It serves as the single source of truth for how we write, review, test, and deliver software.

## What's Covered

- **[Coding Standards](./Coding-Standards.md)** — Language conventions, linting, formatting, and naming rules.
- **[Code Review](./Code-Review.md)** — Review process, expectations, and checklists.
- **[Branching Strategy](./Branching-Strategy.md)** — Branch naming, workflow, and merge rules.
- **[Testing](./Testing.md)** — Testing philosophy, coverage expectations, and test types.
- **[CI/CD](./CI-CD.md)** — Pipeline overview, deployment process, and environment promotion.

## Guiding Principle

Practices documented here represent team consensus. If something feels wrong or outdated, raise it with the team and update the wiki.
