# Ways of Working Wiki — Editor Guide

This repository contains the source for the Ways of Working wiki. Wiki content lives in the `docs/` folder, which is published as the wiki root in Azure DevOps using **Publish code as wiki**.

## Setup

```bash
npm install
```

This installs the markdown tooling and sets up a pre-commit hook via [Husky](https://typicode.github.io/husky/).

## Pre-commit Checks

Every commit that includes markdown files under `docs/` is automatically checked by [lint-staged](https://github.com/lint-staged/lint-staged):

1. **Markdown lint** ([markdownlint-cli2](https://github.com/DavidAnson/markdownlint-cli2)) — structural rules for consistent markdown.
2. **Formatting** ([Prettier](https://prettier.io/)) — consistent whitespace and formatting.
3. **Spell check** ([cspell](https://cspell.org/)) — catches typos using a British English dictionary.

If any check fails, the commit is blocked until the issue is fixed.

## NPM Scripts

| Script | Description |
|--------|-------------|
| `npm run lint` | Lint all wiki markdown files |
| `npm run lint:fix` | Lint and auto-fix where possible |
| `npm run format` | Format all wiki markdown files |
| `npm run format:check` | Check formatting without modifying files |
| `npm run spell` | Spell-check all wiki markdown files |
| `npm run check` | Run lint, format check, and spell check together |

## Adding Dictionary Words

If cspell flags a legitimate technical term, add it to the `words` array in `cspell.json`:

```json
{
  "words": [
    "YourNewWord"
  ]
}
```

Keep the list sorted alphabetically. Prefer adding specific terms rather than disabling the spell checker.

## Wiki Conventions

- **Filenames** — Use PascalCase with dashes: `My-New-Page.md`.
- **Sidebar ordering** — Add new pages to the `.order` file in the same directory so they appear in the Azure DevOps wiki sidebar.
- **Internal links** — Use relative paths with `.md` extensions: `./Code-Review.md` for a sibling page, `../Architecture/Architecture.md` to link across sections. Relative links work both in the Azure DevOps wiki view and when browsing the repo.
- **Language** — Write in British English (e.g., colour, behaviour, organise).
- **Placeholders** — Use HTML comments (`<!-- ... -->`) for sections that need filling in.
