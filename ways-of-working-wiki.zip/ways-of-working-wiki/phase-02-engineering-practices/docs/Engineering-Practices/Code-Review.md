# Code Review

Code review is how we maintain quality, share knowledge, and catch issues early.

## Review Process

<!-- Describe the end-to-end review workflow: who creates PRs, how reviewers are assigned, and what approvals are needed to merge. -->

## Review Checklist

<!-- Provide a checklist reviewers should work through — e.g., correctness, tests, security, readability, documentation. -->

## Turnaround Expectations

<!-- State the expected time to first review and to resolution. Define what to do when a review is blocked or stale. -->
