# Onboarding

Welcome to the team! This section covers everything you need to get productive in your first few weeks.

## Your First Weeks

| Week       | Focus                                                      |
| ---------- | ---------------------------------------------------------- |
| **Week 1** | Accounts, tooling, and environment setup. Meet the team.   |
| **Week 2** | Codebase orientation. Pair with a buddy on a small task.   |
| **Week 3** | First solo contribution. Review engineering practices.     |
| **Week 4** | Reflect on onboarding experience and suggest improvements. |

## Pages in This Section

- **[Getting Started](./Getting-Started.md)** — Day-one checklist to get your accounts and access sorted.
- **[Tooling Setup](./Tooling-Setup.md)** — IDE, extensions, local development environment, and useful aliases.
- **[Key Contacts](./Key-Contacts.md)** — Who to reach out to for what.
- **[Team Culture](./Team-Culture.md)** — Communication norms, meeting etiquette, and team values.
