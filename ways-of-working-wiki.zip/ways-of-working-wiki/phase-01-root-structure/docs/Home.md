# Ways of Working Wiki

Welcome to the Ways of Working Wiki — the shared reference for our engineering practices, architecture decisions, and onboarding guidance.

## Sections

### [Engineering Practices](./Engineering-Practices/Engineering-Practices.md)

Standards and processes for how we write, review, test, and deliver code. Covers coding standards, code review, branching strategy, testing, and CI/CD.

### [Architecture](./Architecture/Architecture.md)

Architectural principles, technology choices, and Architecture Decision Records (ADRs) that capture the reasoning behind significant technical decisions.

### [Onboarding](./Onboarding/Onboarding.md)

Everything a new team member needs to get up and running — from day-one checklists and tooling setup to key contacts and team culture.

## How to Contribute

This wiki is maintained collaboratively by all engineering teams. To contribute:

1. **Edit in place** — Update any page directly when you spot outdated or missing information.
2. **Follow conventions** — Use dash-separated filenames (e.g., `My-New-Page.md`). Add new pages to the relevant `.order` file so they appear in the sidebar.
3. **Keep it concise** — Write for someone who needs the information quickly. Link to external documents for deep dives rather than duplicating content here.
4. **Propose, don't prescribe** — For significant changes to practices or standards, discuss with the team before updating the wiki.
