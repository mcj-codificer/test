Add markdown linting, formatting, and spell-checking tooling
