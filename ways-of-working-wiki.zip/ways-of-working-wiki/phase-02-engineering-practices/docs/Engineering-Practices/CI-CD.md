# CI/CD

Continuous Integration and Continuous Delivery automate the path from code commit to production.

## Pipeline Overview

<!-- Describe the CI/CD tooling and the stages each pipeline runs through (build, test, analyse, package, deploy). -->

## Deployment Process

<!-- Explain how deployments are triggered, who can approve them, and what rollback procedures exist. -->

## Environment Promotion

<!-- Define the environments (e.g., dev, staging, production), how artefacts are promoted between them, and any gating criteria. -->
