# Tooling Setup

This page covers the standard development tooling. Follow these steps to get a consistent local environment.

## IDE

<!-- Specify the recommended IDE (e.g., VS Code, Rider, IntelliJ) and any required settings or workspace configuration files. -->

## Extensions

<!-- List the recommended or required IDE extensions (e.g., ESLint, Prettier, EditorConfig, GitLens). -->

## Local Development Environment

<!-- Describe how to set up the local dev environment — e.g., Docker, SDKs, databases, environment variables. Link to any setup scripts. -->

## Useful Aliases and Scripts

<!-- Share any shell aliases, Git aliases, or helper scripts the team uses to speed up common tasks. -->
