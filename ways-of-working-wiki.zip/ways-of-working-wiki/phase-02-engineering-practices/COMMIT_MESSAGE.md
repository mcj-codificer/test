Add engineering practices section
