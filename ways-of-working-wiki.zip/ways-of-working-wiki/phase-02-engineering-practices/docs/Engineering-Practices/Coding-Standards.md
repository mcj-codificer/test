# Coding Standards

Consistent code style reduces cognitive load during reviews and makes the codebase easier to navigate.

## Language Conventions

<!-- Document the primary languages used and any language-specific conventions the team follows. -->

## Linting

<!-- Specify the linting tools, rulesets, and how they are enforced (e.g., pre-commit hooks, CI checks). -->

## Formatting

<!-- Define the formatting tools (e.g., Prettier, Black) and configuration used across projects. -->

## Naming Conventions

<!-- Describe naming rules for files, classes, functions, variables, database objects, and API endpoints. -->
